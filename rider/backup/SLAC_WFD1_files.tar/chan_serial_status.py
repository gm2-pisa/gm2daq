# this script prints the status of the master-channel serial links for the two WFD1 boards
# -- comment out sections or make another script if you want to check the status of one board by itself

import uhal

hw_man = uhal.ConnectionManager("file://connection.xml")
wfd1_sn4 = hw_man.getDevice("wfd1_sn4")
wfd1_sn2 = hw_man.getDevice("wfd1_sn2")


# check status of serial link on WFD1 S/N 4
status_vals_0 = []
for name in wfd1_sn4.getNode("aurora.chan0.live_status").getNodes():
	val = wfd1_sn4.getNode("aurora.chan0.live_status."+name).read()
	status_vals_0.append((name, val))
wfd1_sn4.dispatch()

print "status of WFD1 S/N 4 master-channel serial link:"
for n, v in status_vals_0:
	print "   ", n, v.value()


# check status of serial link on WFD1 S/N 2
status_vals_0 = []
for name in wfd1_sn2.getNode("aurora.chan0.live_status").getNodes():
	val = wfd1_sn2.getNode("aurora.chan0.live_status."+name).read()
	status_vals_0.append((name, val))
wfd1_sn2.dispatch()

print "status of WFD1 S/N 2 master-channel serial link:"
for n, v in status_vals_0:
	print "   ", n, v.value()

